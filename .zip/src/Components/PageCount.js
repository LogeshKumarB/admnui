export const config = {
    PAGE_COUNT : 10,
}



