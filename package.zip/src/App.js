import "./App.css";
// import { ErrorBoundary } from './ErrorBoundary/ErrorBoundary';
import AdminUI from "./Components/AdminUI";

function App() {
  return (
    <div className="App">
      <AdminUI />
    </div>
  );
}

export default App;
